<?php
/**
 * Plugin Name: WordPress Ask Your Database Custom Chatbot
 * Description: Easily integrate customizable chatbots into your WordPress site using the Ask Your Database API
 * Version: 2.3
 * Author: Ask Your Database
 * Author URI: https://askyourdatabase.com
 * Text Domain: ask-your-database-chatbot
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Activation/Deactivation hooks
register_activation_hook(__FILE__, 'ayd_chatbot_activate');
register_deactivation_hook(__FILE__, 'ayd_chatbot_deactivate');

function ayd_chatbot_activate() {
    // Set default options on activation
    add_option('ayd_chatbot_api_key', '');
}

function ayd_chatbot_deactivate() {
    // Cleanup if needed
}

// Add menu item
add_action('admin_menu', 'ayd_chatbot_add_admin_menu');
function ayd_chatbot_add_admin_menu() {
    add_menu_page(
        'Chatbot Settings',
        'Chatbot',
        'manage_options',
        'ayd-chatbot-settings',
        'ayd_chatbot_settings_page',
        'dashicons-admin-generic',
        90
    );
}

// Add settings page
function ayd_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h1>Chatbot Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ayd_chatbot_options');
            do_settings_sections('ayd_chatbot_settings');
            submit_button();
            ?>
        </form>
        <h2>Get Chat Code/API</h2>
        <iframe src="https://www.askyourdatabase.com/dashboard/chatbot" style="width: 100%; height: 600px; border: none;"></iframe>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'ayd_chatbot_settings_init');
function ayd_chatbot_settings_init() {
    register_setting('ayd_chatbot_options', 'ayd_chatbot_api_key');

    add_settings_section(
        'ayd_chatbot_general_section',
        'General Settings',
        'ayd_chatbot_general_section_callback',
        'ayd_chatbot_settings'
    );

    add_settings_field(
        'ayd_chatbot_api_key',
        'API Key',
        'ayd_chatbot_api_key_render',
        'ayd_chatbot_settings',
        'ayd_chatbot_general_section'
    );
}

function ayd_chatbot_general_section_callback() {
    echo 'Configure your chatbot settings below:';
}

function ayd_chatbot_api_key_render() {
    $api_key = get_option('ayd_chatbot_api_key');
    ?>
    <input type='text' name='ayd_chatbot_api_key' value='<?php echo esc_attr($api_key); ?>'>
    <?php
}

// Original shortcode and functionality
function ayd_chatbot_shortcode($atts) {
    $api_key = get_option('ayd_chatbot_api_key');
    return '<div class="ayd-chatbot">
        <iframe src="https://chat.askyourdatabase.com/' . esc_attr($api_key) . '" style="width: 100%; height: 600px; border: none;"></iframe>
    </div>';
}
add_shortcode('ayd_chatbot', 'ayd_chatbot_shortcode');

// Add settings link on plugin page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ayd_chatbot_settings_link');
function ayd_chatbot_settings_link($links) {
    $settings_link = '<a href="admin.php?page=ayd-chatbot-settings">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}
