<?php
/*
Plugin Name: Ask Your Database Custom Chatbot
Plugin URI: https://www.askyourdatabase.com
Description: A custom chatbot integration for WordPress websites
Version: 2.4
Author: Ask Your Database
Author URI: https://www.askyourdatabase.com
License: GPL v2 or later
Text Domain: ask-your-database
*/

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('ASK_YOUR_DATABASE_VERSION', '2.4');
define('ASK_YOUR_DATABASE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ASK_YOUR_DATABASE_PLUGIN_URL', plugin_dir_url(__FILE__));

// Activation Hook
register_activation_hook(__FILE__, 'ask_your_database_activate');
function ask_your_database_activate() {
    // Set default options
    $default_options = array(
        'api_key' => '',
        'chatbot_settings' => ''
    );
    add_option('ask_your_database_options', $default_options);
    
    // Add activation flag
    add_option('ask_your_database_activated', true);
}

// Deactivation Hook
register_deactivation_hook(__FILE__, 'ask_your_database_deactivate');
function ask_your_database_deactivate() {
    // Cleanup if needed
    delete_option('ask_your_database_activated');
}

// Register Settings
add_action('admin_init', 'ask_your_database_register_settings');
function ask_your_database_register_settings() {
    register_setting(
        'ask_your_database_options',
        'ask_your_database_options',
        'ask_your_database_validate_options'
    );
}

// Validate options
function ask_your_database_validate_options($input) {
    $valid = array();
    $valid['api_key'] = sanitize_text_field($input['api_key']);
    $valid['chatbot_settings'] = wp_kses_post($input['chatbot_settings']);
    return $valid;
}

// Add menu item
add_action('admin_menu', 'ask_your_database_add_menu');
function ask_your_database_add_menu() {
    add_menu_page(
        'Ask Your Database Chatbot',
        'AYD Chatbot',
        'manage_options',
        'ask-your-database',
        'ask_your_database_settings_page',
        'dashicons-format-chat'
    );
}

// Enqueue necessary scripts and styles
add_action('admin_enqueue_scripts', 'ask_your_database_admin_scripts');
function ask_your_database_admin_scripts($hook) {
    if ('toplevel_page_ask-your-database' !== $hook) {
        return;
    }
    
    wp_enqueue_style(
        'ask-your-database-admin',
        plugins_url('css/admin.css', __FILE__),
        array(),
        ASK_YOUR_DATABASE_VERSION
    );
    
    wp_enqueue_script(
        'ask-your-database-admin',
        plugins_url('js/admin.js', __FILE__),
        array('jquery'),
        ASK_YOUR_DATABASE_VERSION,
        true
    );
}

// Settings page
function ask_your_database_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    ?>
    <div class="wrap">
        <h2>Ask Your Database Custom Chatbot</h2>
        <div class="ayd-tabs">
            <button class="ayd-tab-link active" onclick="openAydTab(event, 'settings')">Settings</button>
            <button class="ayd-tab-link" onclick="openAydTab(event, 'shortcodes')">Shortcodes</button>
            <button class="ayd-tab-link" onclick="openAydTab(event, 'api-codes')">API Chatbot Codes</button>
        </div>

        <div id="settings" class="ayd-tab-content active">
            <form method="post" action="options.php">
                <?php
                settings_fields('ask_your_database_options');
                do_settings_sections('ask_your_database');
                $options = get_option('ask_your_database_options');
                ?>
                <table class="form-table">
<tr>
    <th scope="row">Universal API Key</th>
    <td>
        <input type="text" name="ask_your_database_options[universal_api_key]" 
            value="<?php echo esc_attr($options['universal_api_key']); ?>" class="regular-text">
    </td>
</tr>
<tr>
    <th scope="row">Chatbot Code</th>
    <td>
        <input type="text" name="ask_your_database_options[chatbot_code]" 
            value="<?php echo esc_attr($options['chatbot_code']); ?>" class="regular-text">
    </td>
</tr>
<tr>
    <th scope="row">Chatbot Name</th>
    <td>
        <input type="text" name="ask_your_database_options[chatbot_name]" 
            value="<?php echo esc_attr($options['chatbot_name']); ?>" class="regular-text">
    </td>
</tr>
<tr>
    <th scope="row">Shortcode</th>
    <td>
        <div class="shortcode-box">[ask_your_database_chatbot]</div>
    </td>
</tr>
</table>
                <?php submit_button(); ?>
            </form>
        </div>

        <div id="shortcodes" class="ayd-tab-content">
            <h3>Available Shortcodes</h3>
            <div class="shortcode-box">
                [ask_your_database_chatbot]
            </div>
            <p>Use this shortcode to embed the chatbot in any post or page.</p>
        </div>

        <div id="api-codes" class="ayd-tab-content">
            <h3>API Integration</h3>
            <div class="ayd-iframe-container">
                <iframe src="https://www.askyourdatabase.com/dashboard/chatbot"></iframe>
            </div>
        </div>
    </div>

    <style>
        .ayd-tabs {
            display: flex;
            background-color: #333;
            overflow: hidden;
            margin-top: 20px;
        }
        .ayd-tab-link {
            background-color: inherit;
            color: white;
            padding: 14px 20px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            flex: 1;
        }
        .ayd-tab-link:hover {
            background-color: #ddd;
            color: black;
        }
        .ayd-tab-link.active {
            background-color: #4CAF50;
            color: white;
        }
        .ayd-tab-content {
            display: none;
            padding: 20px;
            border: 1px solid #ccc;
        }
        .ayd-tab-content.active {
            display: block;
        }
        .shortcode-box {
            background-color: #f1f1f1;
            border: 1px solid #ccc;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            font-family: monospace;
        }
        .ayd-iframe-container {
            position: relative;
            width: 100%;
            height: 600px;
            border: 1px solid #ddd;
            border-radius: 5px;
            overflow: hidden;
        }
        .ayd-iframe-container iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>

    <script>
    function openAydTab(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("ayd-tab-content");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("ayd-tab-link");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
    }
    </script>
    <?php
}

// Add shortcode
add_shortcode('ask_your_database_chatbot', 'ask_your_database_shortcode');
function ask_your_database_shortcode($atts) {
    $options = get_option('ask_your_database_options');
    $api_key = esc_attr($options['api_key']);
    
    ob_start();
    ?>
    <div id="ask-your-database-chatbot" data-api-key="<?php echo $api_key; ?>"></div>
    <?php
    return ob_get_clean();
}

// Frontend scripts and styles
add_action('wp_enqueue_scripts', 'ask_your_database_frontend_scripts');
function ask_your_database_frontend_scripts() {
    if (has_shortcode(get_post()->post_content, 'ask_your_database_chatbot')) {
        wp_enqueue_script(
            'ask-your-database-frontend',
            plugins_url('js/frontend.js', __FILE__),
            array('jquery'),
            ASK_YOUR_DATABASE_VERSION,
            true
        );

        wp_localize_script('ask-your-database-frontend', 'aydSettings', array(
            'apiUrl' => 'https://www.askyourdatabase.com/api'
        ));
    }
}
