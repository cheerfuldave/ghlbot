
jQuery(document).ready(function($) {
    // Initialize chatbot
    var chatbotContainer = $('#ask-your-database-chatbot');
    var apiKey = chatbotContainer.data('api-key');
    
    // Add chatbot initialization code here
});
