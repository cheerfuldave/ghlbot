<?php
/*
Plugin Name: Ask Your Database Custom Chatbot
Description: A custom chatbot plugin for WordPress.
Version: 2.4
Author: Your Name
License: GPLv2 or later
*/
<?php
/*
Plugin Name: WordPress Ask Your Database Custom Chatbot
Description: Easily integrate customizable chatbots into your WordPress site using the Ask Your Database API.
Version: 2.0
Author: Ask Your Database
Author URI: https://askyourdatabase.com
*/

// Register plugin settings
add_action('admin_menu', 'ayd_chatbot_integration_menu');
function ayd_chatbot_integration_menu() {
    add_menu_page(
        'Chatbot Settings',
        'Chatbot Settings',
        'manage_options',
        'ayd-chatbot-settings',
        'ayd_chatbot_settings_page'
    );
}

// Settings page with enhanced instructions and full user list for selection
function ayd_chatbot_settings_page() {
    if (isset($_POST['save_settings'])) {
        $chatbots = isset($_POST['chatbots']) ? array_map(function($chatbot) {
            return array(
                'name' => sanitize_text_field($chatbot['name']),
                'id' => sanitize_text_field($chatbot['id']),
            );
        }, $_POST['chatbots']) : array();

        $selected_users = isset($_POST['selected_users']) ? array_map('intval', $_POST['selected_users']) : array();

        update_option('ayd_chatbots', $chatbots);
        update_option('ayd_api_key', sanitize_text_field($_POST['api_key']));
        update_option('ayd_selected_users', $selected_users);

        echo '<div class="updated"><p>Settings saved successfully.</p></div>';
    }

    $api_key = get_option('ayd_api_key', '');
    $chatbots = get_option('ayd_chatbots', array());
    $selected_users = get_option('ayd_selected_users', array());

    if (!is_array($chatbots)) {
        $chatbots = array();
    }

    echo '
    <div class="wrap">
        <h1>Ask Your Database Chatbot Integration</h1>
        <p>Follow the steps below to configure your chatbots:</p>
        <ol>
            <li>
                Enter your <strong>API Key</strong>, which can be found on your 
                <a href="https://www.askyourdatabase.com/dashboard/api-key" target="_blank">Ask Your Database API Keys page</a>.
            </li>
            <li>
                Go to the <a href="https://www.askyourdatabase.com/dashboard/" target="_blank">Chatbot Dashboard</a>, click 
                <strong>Integrate</strong> on the selected chatbot, and retrieve the <strong>Chatbot ID</strong>.
            </li>
            <li>
                Provide a unique name and Chatbot ID for each chatbot you want to configure.
            </li>
            <li>
                Select the users who can access the configured chatbots.
            </li>
            <li>
                Save the settings and use the shortcodes displayed below to embed the chatbot into your WordPress site.
            </li>
        </ol>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th><label for="api_key">API Key</label></th>
                    <td><input type="text" id="api_key" name="api_key" value="' . esc_attr($api_key) . '" class="regular-text"></td>
                </tr>
                <tr>
                    <th colspan="2"><h3>Chatbot Configurations</h3></th>
                </tr>';

    for ($i = 0; $i < 5; $i++) {
        $chatbot_label = "Chatbot " . ($i + 1);
        $name = isset($chatbots[$i]['name']) ? $chatbots[$i]['name'] : '';
        $id = isset($chatbots[$i]['id']) ? $chatbots[$i]['id'] : '';
        echo '
                <tr>
                    <th colspan="2"><h4>' . $chatbot_label . '</h4></th>
                </tr>
                <tr>
                    <th><label for="chatbots[' . $i . '][name]">Chatbot Name</label></th>
                    <td><input type="text" name="chatbots[' . $i . '][name]" value="' . esc_attr($name) . '" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="chatbots[' . $i . '][id]">Chatbot ID</label></th>
                    <td><input type="text" name="chatbots[' . $i . '][id]" value="' . esc_attr($id) . '" class="regular-text"></td>
                </tr>';
    }

    // Full user selection list
    echo '
                <tr>
                    <th><label for="selected_users">Select Users</label></th>
                    <td>
                        <select id="selected_users" name="selected_users[]" multiple style="width: 100%;">';

    $users = get_users(array('fields' => array('ID', 'display_name', 'user_email')));
    foreach ($users as $user) {
        $selected = in_array($user->ID, $selected_users) ? 'selected' : '';
        echo '<option value="' . esc_attr($user->ID) . '" ' . $selected . '>' . esc_html($user->display_name) . ' (' . esc_html($user->user_email) . ')</option>';
    }

    echo '
                        </select>
                        <p class="description">Hold down the Ctrl (Windows) or Command (Mac) key to select multiple users.</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="save_settings" value="Save Settings" class="button-primary"></p>
        </form>';

    // Display shortcodes for configured chatbots
    echo '<h2>Available Chatbot Shortcodes</h2>';
    echo '<p>Use the following shortcodes to display your configured chatbots:</p>';
    echo '<ul>';
    foreach ($chatbots as $chatbot) {
        if (!empty($chatbot['name'])) {
            echo '<li><code>[chatbot chatbot="' . esc_html($chatbot['name']) . '"]</code></li>';
        }
    }
    echo '</ul>';

    echo '</div>';
}

// Shortcode to display chatbot only for selected users
function ayd_chatbot_shortcode($atts) {
    $atts = shortcode_atts(
        array('chatbot' => ''),
        $atts,
        'chatbot'
    );

    $chatbot_name = sanitize_text_field($atts['chatbot']);
    $chatbots = get_option('ayd_chatbots', array());
    $selected_users = get_option('ayd_selected_users', array());

    $chatbot_config = array_filter($chatbots, function ($chatbot) use ($chatbot_name) {
        return isset($chatbot['name']) && $chatbot['name'] === $chatbot_name;
    });

    $user = wp_get_current_user();
    if (empty($chatbots) || empty($chatbot_config) || !$user->exists() || !in_array($user->ID, $selected_users)) {
        return '<p>You do not have access to this chatbot.</p>';
    }

    $api_key = get_option('ayd_api_key', '');
    if (!$api_key) {
        return '<p>API Key is missing. Please configure it in the settings.</p>';
    }

    $chatbot_id = reset($chatbot_config)['id'];

    $session_url = ayd_generate_session_url($api_key, $chatbot_id, $user->display_name, $user->user_email);

    if (!$session_url) {
        return '<p>Unable to generate chatbot session. Please try again later.</p>';
    }

    return '
    <div class="chatbot-container">
        <h3 style="text-align: center; font-size: 20px; margin-bottom: 10px;">Ask Your Database - ' . esc_html($chatbot_name) . '</h3>
        <iframe src="' . esc_url($session_url) . '" style="width: 100%; height: 600px; border: none;"></iframe>
    </div>';
}
add_shortcode('chatbot', 'ayd_chatbot_shortcode');

// Generate session URL
function ayd_generate_session_url($api_key, $chatbot_id, $name, $email) {
    $response = wp_remote_post('https://www.askyourdatabase.com/api/chatbot/v2/session', array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ),
        'body' => json_encode(array(
            'chatbotid' => $chatbot_id,
            'name' => $name,
            'email' => $email,
        )),
    ));

    if (is_wp_error($response)) {
        return false;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    return $body['url'] ?? false;
}

// Enqueue basic styles
add_action('wp_head', function () {
    echo '
    <style>
    .chatbot-container {
        max-width: 800px;
        margin: 20px auto;
        border: 1px solid #ccc;
        border-radius: 10px;
        overflow: hidden;
    }
    </style>';
});
?>


function ask_your_database_settings_page() {
    ?>
    <div class="wrap">
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
            <style>
                .ayd-wrap {
                    font-family: 'Roboto', sans-serif;
                    margin: 0;
                    padding: 20px;
                    background-color: #f9f9f9;
                }
                .ayd-header {
                    background-color: #4CAF50;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                    margin-bottom: 0;
                }
                .ayd-header img {
                    max-height: 50px;
                    vertical-align: middle;
                }
                .ayd-tabs {
                    display: flex;
                    background-color: #333;
                    overflow: hidden;
                    margin-bottom: 0;
                }
                .ayd-tabs button {
                    background-color: inherit;
                    color: white;
                    padding: 14px 20px;
                    border: none;
                    cursor: pointer;
                    transition: 0.3s;
                    flex: 1;
                }
                .ayd-tabs button:hover {
                    background-color: #ddd;
                    color: black;
                }
                .ayd-tabs button.active {
                    background-color: #4CAF50;
                    color: white;
                }
                .ayd-tab-content {
                    display: none;
                    padding: 20px;
                    background-color: white;
                    border: 1px solid #ccc;
                    margin-top: 0;
                }
                .ayd-tab-content.active {
                    display: block;
                }
                .shortcode-box {
                    background-color: #f1f1f1;
                    border: 1px solid #ccc;
                    padding: 15px;
                    margin: 10px 0;
                    border-radius: 5px;
                    font-family: monospace;
                }
                .ayd-iframe-container {
                    position: relative;
                    width: 100%;
                    height: 600px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    overflow: hidden;
                }
                .ayd-iframe-container iframe {
                    width: 100%;
                    height: 100%;
                    border: none;
                }
                .ayd-settings-form {
                    max-width: 800px;
                    margin: 20px auto;
                }
                .ayd-settings-form label {
                    display: block;
                    margin: 15px 0 5px;
                    font-weight: bold;
                }
                .ayd-settings-form input[type="text"],
                .ayd-settings-form textarea {
                    width: 100%;
                    padding: 8px;
                    margin-bottom: 10px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
                .ayd-settings-form input[type="submit"] {
                    background-color: #4CAF50;
                    color: white;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }
            </style>
        </head>
        <body>
            <div class="ayd-wrap">
                <div class="ayd-header">
                    <img src="https://storage.googleapis.com/msgsndr/me0EnocxsZH10tkDWF5K/media/67253ad0eded3ba14cf5b7e0.png" alt="Logo">
                    <h1>Ask Your Database Custom Chatbot</h1>
                </div>
                
                <div class="ayd-tabs">
                    <button class="ayd-tab-link active" onclick="openAydTab(event, 'settings')">Settings</button>
                    <button class="ayd-tab-link" onclick="openAydTab(event, 'shortcodes')">Shortcodes</button>
                    <button class="ayd-tab-link" onclick="openAydTab(event, 'api-codes')">API Chatbot Codes</button>
                </div>

                <div id="settings" class="ayd-tab-content active">
                    <div class="ayd-settings-form">
                        <form method="post" action="options.php">
                            <?php settings_fields('ask_your_database_options'); ?>
                            <?php do_settings_sections('ask_your_database'); ?>
                            <label for="api_key">API Key:</label>
                            <input type="text" id="api_key" name="ask_your_database_options[api_key]" 
                                value="<?php echo esc_attr(get_option('ask_your_database_options')['api_key']); ?>">
                            
                            <label for="chatbot_settings">Chatbot Settings:</label>
                            <textarea id="chatbot_settings" name="ask_your_database_options[chatbot_settings]" rows="5"
                                ><?php echo esc_textarea(get_option('ask_your_database_options')['chatbot_settings']); ?></textarea>
                            
                            <?php submit_button('Save Settings'); ?>
                        </form>
                    </div>
                </div>

                <div id="shortcodes" class="ayd-tab-content">
                    <h2>Available Shortcodes</h2>
                    <div class="shortcode-box">
                        [ask_your_database_chatbot]
                    </div>
                    <p>Use this shortcode to embed the chatbot in any post or page.</p>
                </div>

                <div id="api-codes" class="ayd-tab-content">
                    <h2>API Integration</h2>
                    <div class="ayd-iframe-container">
                        <iframe src="https://www.askyourdatabase.com/dashboard/chatbot"></iframe>
                    </div>
                </div>
            </div>

            <script>
                function openAydTab(evt, tabName) {
                    var i, tabcontent, tablinks;
                    tabcontent = document.getElementsByClassName("ayd-tab-content");
                    for (i = 0; i < tabcontent.length; i++) {
                        tabcontent[i].style.display = "none";
                    }
                    tablinks = document.getElementsByClassName("ayd-tab-link");
                    for (i = 0; i < tablinks.length; i++) {
                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                    }
                    document.getElementById(tabName).style.display = "block";
                    evt.currentTarget.className += " active";
                }
            </script>
        </body>
        </html>
    </div>
    <?php
}

// Register activation hook
register_activation_hook(__FILE__, 'ask_your_database_activate');
function ask_your_database_activate() {
    // Activation logic here
}

// Register settings
add_action('admin_init', 'ask_your_database_register_settings');
function ask_your_database_register_settings() {
    register_setting('ask_your_database_options', 'ask_your_database_options');
}

// Add shortcode
add_shortcode('ask_your_database_chatbot', 'ask_your_database_shortcode');
function ask_your_database_shortcode($atts) {
    return '<div id="ask-your-database-chatbot"></div>';
}
