<?php
class AYD_Chatbot_Deactivator {
    public static function deactivate() {
        // Cleanup tasks if needed
        // Note: We don't delete options or tables to preserve user data
    }
}
