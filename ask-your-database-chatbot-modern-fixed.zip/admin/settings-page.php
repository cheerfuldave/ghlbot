<?php
// Settings page for the plugin
function ayd_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h1>Chatbot Settings</h1>
        <div class="tabs">
            <button class="tab-button" data-tab="general">General</button>
            <button class="tab-button" data-tab="appearance">Appearance</button>
            <button class="tab-button" data-tab="advanced">Advanced</button>
        </div>
        <div class="tab-content" id="general">
            <h2>General Settings</h2>
            <form id="general-settings-form">
                <label for="api_key">API Key:</label>
                <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr(get_option('ayd_chatbot_api_key')); ?>">
                <button type="submit">Save</button>
            </form>
        </div>
        <div class="tab-content" id="appearance">
            <h2>Appearance Settings</h2>
            <form id="appearance-settings-form">
                <label for="theme">Theme:</label>
                <select id="theme" name="theme">
                    <option value="light" <?php selected(get_option('ayd_chatbot_theme'), 'light'); ?>>Light</option>
                    <option value="dark" <?php selected(get_option('ayd_chatbot_theme'), 'dark'); ?>>Dark</option>
                </select>
                <button type="submit">Save</button>
            </form>
        </div>
        <div class="tab-content" id="advanced">
            <h2>Advanced Settings</h2>
            <form id="advanced-settings-form">
                <label for="custom_css">Custom CSS:</label>
                <textarea id="custom_css" name="custom_css"><?php echo esc_textarea(get_option('ayd_chatbot_custom_css')); ?></textarea>
                <button type="submit">Save</button>
            </form>
        </div>
    </div>
    <?php
}
?>

    add_action('admin_menu', 'ayd_chatbot_add_admin_menu');

    function ayd_chatbot_add_admin_menu() {
        add_menu_page(
            'Chatbot Settings',
            'Chatbot',
            'manage_options',
            'ayd-chatbot-settings',
            'ayd_chatbot_settings_page',
            'dashicons-admin-generic',
            90
        );
    }
    