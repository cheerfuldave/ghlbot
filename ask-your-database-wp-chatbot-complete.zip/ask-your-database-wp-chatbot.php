<?php
/*
Plugin Name: Ask Your Database
Plugin URI: https://askyourdatabase.com
Description: Query your WordPress database with natural language
Version: 2.0.0
Author: Ask Your Database
Author URI: https://askyourdatabase.com
*/

if (!defined('ABSPATH')) exit;

// Add admin menu
add_action('admin_menu', 'ask_your_database_menu');

function ask_your_database_menu() {
    add_menu_page(
        'Ask Your Database Settings', // page title
        'Ask Your Database',         // menu title
        'manage_options',            // capability
        'ask-your-database',         // menu slug
        'ask_your_database_page',    // callback function
        'dashicons-database',        // icon
        30                          // position
    );
}

function ask_your_database_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ask_your_database_options');
            do_settings_sections('ask-your-database');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register Settings
add_action('admin_init', 'ask_your_database_settings_init');

function ask_your_database_settings_init() {
    register_setting('ask_your_database_options', 'ask_your_database_settings');

    // API Section
    add_settings_section(
        'ask_your_database_api_section',
        'API Configuration',
        'ask_your_database_api_section_callback',
        'ask-your-database'
    );

    add_settings_field(
        'api_key',
        'API Key',
        'ask_your_database_api_key_callback',
        'ask-your-database',
        'ask_your_database_api_section'
    );

    // Database Section
    add_settings_section(
        'ask_your_database_db_section',
        'Database Settings',
        'ask_your_database_db_section_callback',
        'ask-your-database'
    );

    add_settings_field(
        'db_host',
        'Database Host',
        'ask_your_database_db_host_callback',
        'ask-your-database',
        'ask_your_database_db_section'
    );

    add_settings_field(
        'db_name',
        'Database Name',
        'ask_your_database_db_name_callback',
        'ask-your-database',
        'ask_your_database_db_section'
    );

    add_settings_field(
        'db_user',
        'Database User',
        'ask_your_database_db_user_callback',
        'ask-your-database',
        'ask_your_database_db_section'
    );

    add_settings_field(
        'db_password',
        'Database Password',
        'ask_your_database_db_password_callback',
        'ask-your-database',
        'ask_your_database_db_section'
    );

    // Chatbot Section
    add_settings_section(
        'ask_your_database_chatbot_section',
        'Chatbot Settings',
        'ask_your_database_chatbot_section_callback',
        'ask-your-database'
    );

    add_settings_field(
        'chatbot_theme',
        'Chatbot Theme',
        'ask_your_database_chatbot_theme_callback',
        'ask-your-database',
        'ask_your_database_chatbot_section'
    );

    add_settings_field(
        'chatbot_position',
        'Chatbot Position',
        'ask_your_database_chatbot_position_callback',
        'ask-your-database',
        'ask_your_database_chatbot_section'
    );

    // Security Section
    add_settings_section(
        'ask_your_database_security_section',
        'Security Settings',
        'ask_your_database_security_section_callback',
        'ask-your-database'
    );

    add_settings_field(
        'allowed_roles',
        'Allowed User Roles',
        'ask_your_database_allowed_roles_callback',
        'ask-your-database',
        'ask_your_database_security_section'
    );
}

// Section Callbacks
function ask_your_database_api_section_callback() {
    echo '<p>Enter your API credentials below:</p>';
}

function ask_your_database_db_section_callback() {
    echo '<p>Configure your database connection settings:</p>';
}

function ask_your_database_chatbot_section_callback() {
    echo '<p>Customize how your chatbot looks and behaves:</p>';
}

function ask_your_database_security_section_callback() {
    echo '<p>Configure security settings and access permissions:</p>';
}

// Field Callbacks
function ask_your_database_api_key_callback() {
    $options = get_option('ask_your_database_settings');
    ?>
    <input type='text' name='ask_your_database_settings[api_key]' 
           value='<?php echo isset($options['api_key']) ? esc_attr($options['api_key']) : ''; ?>'
           class='regular-text'>
    <?php
}

function ask_your_database_db_host_callback() {
    $options = get_option('ask_your_database_settings');
    ?>
    <input type='text' name='ask_your_database_settings[db_host]' 
           value='<?php echo isset($options['db_host']) ? esc_attr($options['db_host']) : 'localhost'; ?>'
           class='regular-text'>
    <?php
}

function ask_your_database_db_name_callback() {
    $options = get_option('ask_your_database_settings');
    ?>
    <input type='text' name='ask_your_database_settings[db_name]' 
           value='<?php echo isset($options['db_name']) ? esc_attr($options['db_name']) : DB_NAME; ?>'
           class='regular-text'>
    <?php
}

function ask_your_database_db_user_callback() {
    $options = get_option('ask_your_database_settings');
    ?>
    <input type='text' name='ask_your_database_settings[db_user]' 
           value='<?php echo isset($options['db_user']) ? esc_attr($options['db_user']) : DB_USER; ?>'
           class='regular-text'>
    <?php
}

function ask_your_database_db_password_callback() {
    $options = get_option('ask_your_database_settings');
    ?>
    <input type='password' name='ask_your_database_settings[db_password]' 
           value='<?php echo isset($options['db_password']) ? esc_attr($options['db_password']) : ''; ?>'
           class='regular-text'>
    <?php
}

function ask_your_database_chatbot_theme_callback() {
    $options = get_option('ask_your_database_settings');
    $current = isset($options['chatbot_theme']) ? $options['chatbot_theme'] : 'light';
    ?>
    <select name='ask_your_database_settings[chatbot_theme]'>
        <option value='light' <?php selected($current, 'light'); ?>>Light</option>
        <option value='dark' <?php selected($current, 'dark'); ?>>Dark</option>
        <option value='custom' <?php selected($current, 'custom'); ?>>Custom</option>
    </select>
    <?php
}

function ask_your_database_chatbot_position_callback() {
    $options = get_option('ask_your_database_settings');
    $current = isset($options['chatbot_position']) ? $options['chatbot_position'] : 'bottom-right';
    ?>
    <select name='ask_your_database_settings[chatbot_position]'>
        <option value='bottom-right' <?php selected($current, 'bottom-right'); ?>>Bottom Right</option>
        <option value='bottom-left' <?php selected($current, 'bottom-left'); ?>>Bottom Left</option>
        <option value='top-right' <?php selected($current, 'top-right'); ?>>Top Right</option>
        <option value='top-left' <?php selected($current, 'top-left'); ?>>Top Left</option>
    </select>
    <?php
}

function ask_your_database_allowed_roles_callback() {
    $options = get_option('ask_your_database_settings');
    $roles = get_editable_roles();
    $saved_roles = isset($options['allowed_roles']) ? (array) $options['allowed_roles'] : array('administrator');
    
    foreach($roles as $role_key => $role) {
        ?>
        <label>
            <input type='checkbox' name='ask_your_database_settings[allowed_roles][]' 
                   value='<?php echo esc_attr($role_key); ?>'
                   <?php checked(in_array($role_key, $saved_roles), true); ?>>
            <?php echo esc_html($role['name']); ?>
        </label><br>
        <?php
    }
}

// Validate settings
add_filter('pre_update_option_ask_your_database_settings', 'ask_your_database_validate_settings', 10, 2);

function ask_your_database_validate_settings($new_value, $old_value) {
    // Validate API Key
    if (empty($new_value['api_key'])) {
        add_settings_error(
            'ask_your_database_settings',
            'api_key_error',
            'API Key cannot be empty'
        );
        return $old_value;
    }

    // Validate Database Settings
    if (empty($new_value['db_host']) || empty($new_value['db_name']) || 
        empty($new_value['db_user']) || empty($new_value['db_password'])) {
        add_settings_error(
            'ask_your_database_settings',
            'db_settings_error',
            'All database fields are required'
        );
        return $old_value;
    }

    return $new_value;
}
