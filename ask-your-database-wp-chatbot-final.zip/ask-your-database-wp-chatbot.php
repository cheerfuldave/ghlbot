<?php
/*
Plugin Name: Ask Your Database
Plugin URI: https://askyourdatabase.com
Description: Query your WordPress database with natural language
Version: 2.0.0
Author: Ask Your Database
Author URI: https://askyourdatabase.com
*/

if (!defined('ABSPATH')) exit;

function ask_your_database_init() {
    // Init
}
add_action('init', 'ask_your_database_init');