<?php
class AYD_Chatbot_Activator {
    public static function activate() {
        // Add default options
        add_option('ayd_chatbot_api_key', '');
        add_option('ayd_chatbot_settings', array(
            'position' => 'bottom-right',
            'theme' => 'light',
            'height' => '500px',
            'width' => '350px'
        ));
        
        // Create necessary database tables if needed
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ayd_chatbot_conversations` (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            conversation_data longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
