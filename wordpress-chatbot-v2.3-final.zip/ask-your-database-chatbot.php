<?php
/*
Plugin Name: Ask Your Database Chatbot
Plugin URI: https://askyourdatabase.com
Description: WordPress plugin for Ask Your Database chatbot integration
Version: 2.3
Author: Ask Your Database
Author URI: https://askyourdatabase.com
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Add menu
function ayd_chatbot_menu() {
    add_menu_page(
        'Ask Your Database Chatbot',
        'AYD Chatbot',
        'manage_options',
        'ayd-chatbot',
        'ayd_chatbot_settings_page',
        'dashicons-format-chat'
    );
}
add_action('admin_menu', 'ayd_chatbot_menu');

// Register settings
function ayd_chatbot_register_settings() {
    register_setting('ayd_chatbot_settings', 'ayd_chatbot_api_key');
    register_setting('ayd_chatbot_settings', 'ayd_chatbot_name');
    register_setting('ayd_chatbot_settings', 'ayd_chatbot_code');
    register_setting('ayd_chatbot_settings', 'ayd_chatbot_shortcode');
}
add_action('admin_init', 'ayd_chatbot_register_settings');

// Settings page
function ayd_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h2>Ask Your Database Chatbot Settings</h2>
        
        <h2 class="nav-tab-wrapper">
            <a href="#settings" class="nav-tab nav-tab-active" id="settings-tab">Settings</a>
            <a href="#get-code" class="nav-tab" id="get-code-tab">Get Chat Code/API</a>
        </h2>

        <div id="settings-content" class="tab-content active">
            <form method="post" action="options.php">
                <?php settings_fields('ayd_chatbot_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">API Key</th>
                        <td>
                            <input type="text" name="ayd_chatbot_api_key" value="<?php echo esc_attr(get_option('ayd_chatbot_api_key')); ?>" class="regular-text" />
                            <p class="description">Enter your API key from Ask Your Database dashboard</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Chatbot Name</th>
                        <td>
                            <input type="text" name="ayd_chatbot_name" value="<?php echo esc_attr(get_option('ayd_chatbot_name')); ?>" class="regular-text" />
                            <p class="description">Give your chatbot a custom name (optional)</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Chatbot Code</th>
                        <td>
                            <textarea name="ayd_chatbot_code" rows="5" cols="50"><?php echo esc_textarea(get_option('ayd_chatbot_code')); ?></textarea>
                            <p class="description">Custom code for your chatbot (optional)</p>
                        </td>
                    </tr>
                </table>

                <h3>Instructions</h3>
                <div class="card" style="max-width: 800px; padding: 20px; margin-top: 20px;">
                    <h4>How to Use:</h4>
                    <ol>
                        <li>Get your API key from the "Get Chat Code/API" tab</li>
                        <li>Enter your API key above</li>
                        <li>Configure optional settings (name, custom code)</li>
                        <li>Use shortcodes to display the chatbot</li>
                    </ol>

                    <h4>Available Shortcodes:</h4>
                    <ul>
                        <li><code>[ayd_chatbot]</code> - Basic chatbot</li>
                        <li><code>[ayd_chatbot theme="dark"]</code> - Dark theme</li>
                        <li><code>[ayd_chatbot position="left"]</code> - Left alignment</li>
                        <li><code>[ayd_chatbot floating="true"]</code> - Floating chat button</li>
                    </ul>

                    <h4>Additional Settings:</h4>
                    <ul>
                        <li>Theme options: light (default), dark</li>
                        <li>Position options: right (default), left, center</li>
                        <li>Floating options: true, false (default)</li>
                    </ul>
                </div>

                <?php submit_button('Save Settings'); ?>
            </form>
        </div>

        <div id="get-code-content" class="tab-content" style="display: none;">
            <iframe src="https://www.askyourdatabase.com/dashboard/chatbot" style="width: 100%; height: 600px; border: none;"></iframe>
        </div>
    </div>

    <style>
        .tab-content { padding: 20px 0; }
        .card { background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
        .form-table th { width: 200px; }
    </style>

    <script>
    jQuery(document).ready(function($) {
        // Tab functionality
        $('.nav-tab').click(function(e) {
            e.preventDefault();
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            $('.tab-content').hide();
            $($(this).attr('href') + '-content').show();
        });
    });
    </script>
    <?php
}

// Shortcode
function ayd_chatbot_shortcode($atts) {
    $defaults = array(
        'theme' => 'light',
        'position' => 'right',
        'floating' => 'false'
    );
    
    $atts = shortcode_atts($defaults, $atts);
    $api_key = get_option('ayd_chatbot_api_key');
    $name = get_option('ayd_chatbot_name');
    $custom_code = get_option('ayd_chatbot_code');
    
    if (!$api_key) {
        return '<p>Please configure your API key in the AYD Chatbot settings.</p>';
    }
    
    $classes = array('ayd-chatbot');
    $classes[] = 'theme-' . esc_attr($atts['theme']);
    $classes[] = 'position-' . esc_attr($atts['position']);
    if ($atts['floating'] === 'true') {
        $classes[] = 'floating';
    }
    
    $output = '<div class="' . esc_attr(implode(' ', $classes)) . '">';
    if ($name) {
        $output .= '<div class="chatbot-name">' . esc_html($name) . '</div>';
    }
    
    $url = 'https://www.askyourdatabase.com/chat/' . esc_attr($api_key);
    if ($atts['theme'] === 'dark') {
        $url .= '?theme=dark';
    }
    
    $output .= '<iframe src="' . esc_url($url) . '" 
                        style="width: 100%; height: 600px; border: none;"
                        title="Ask Your Database Chatbot"></iframe>';
    
    if ($custom_code) {
        $output .= $custom_code;
    }
    
    $output .= '</div>';
    
    // Add custom CSS
    $output .= '<style>
        .ayd-chatbot { margin: 20px 0; }
        .ayd-chatbot.position-left { float: left; margin-right: 20px; }
        .ayd-chatbot.position-right { float: right; margin-left: 20px; }
        .ayd-chatbot.floating { position: fixed; bottom: 20px; right: 20px; width: 350px; }
        .ayd-chatbot.floating.position-left { right: auto; left: 20px; }
        .chatbot-name { font-weight: bold; margin-bottom: 10px; }
        .theme-dark { background: #1a1a1a; color: #fff; }
    </style>';
    
    return $output;
}
add_shortcode('ayd_chatbot', 'ayd_chatbot_shortcode');

// Add settings link on plugin page
function ayd_chatbot_settings_link($links) {
    $settings_link = '<a href="admin.php?page=ayd-chatbot">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ayd_chatbot_settings_link');
