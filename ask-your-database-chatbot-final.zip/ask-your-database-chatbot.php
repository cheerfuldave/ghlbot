<?php
/**
 * Plugin Name: WordPress Ask Your Database Custom Chatbot
 * Description: Easily integrate customizable chatbots into your WordPress site using the Ask Your Database API
 * Version: 2.3
 * Author: Ask Your Database
 * Author URI: https://askyourdatabase.com
 * Text Domain: ask-your-database-chatbot
 */

if (!defined('WPINC')) {
    die;
}

register_activation_hook(__FILE__, 'ayd_chatbot_activate');
register_deactivation_hook(__FILE__, 'ayd_chatbot_deactivate');

function ayd_chatbot_activate() {
    add_option('ayd_chatbot_api_key', '');
    add_option('ayd_chatbot_name', '');
    add_option('ayd_chatbot_code', '');
}

function ayd_chatbot_deactivate() {
    delete_option('ayd_chatbot_api_key');
    delete_option('ayd_chatbot_name');
    delete_option('ayd_chatbot_code');
}

add_action('admin_menu', 'ayd_chatbot_add_admin_menu');
function ayd_chatbot_add_admin_menu() {
    add_menu_page(
        'Chatbot Settings',
        'Chatbot',
        'manage_options',
        'ayd-chatbot-settings',
        'ayd_chatbot_settings_page',
        'dashicons-format-chat',
        90
    );
}

function ayd_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h1>Chatbot Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ayd_chatbot_options');
            do_settings_sections('ayd_chatbot_settings');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">API Key</th>
                    <td><input type="text" name="ayd_chatbot_api_key" value="<?php echo esc_attr(get_option('ayd_chatbot_api_key')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chatbot Name</th>
                    <td><input type="text" name="ayd_chatbot_name" value="<?php echo esc_attr(get_option('ayd_chatbot_name')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chatbot Code</th>
                    <td><textarea name="ayd_chatbot_code" rows="5" cols="50"><?php echo esc_textarea(get_option('ayd_chatbot_code')); ?></textarea></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', 'ayd_chatbot_settings_init');
function ayd_chatbot_settings_init() {
    register_setting('ayd_chatbot_options', 'ayd_chatbot_api_key');
    register_setting('ayd_chatbot_options', 'ayd_chatbot_name');
    register_setting('ayd_chatbot_options', 'ayd_chatbot_code');
}

register_activation_hook(__FILE__, 'ayd_chatbot_activate');
register_deactivation_hook(__FILE__, 'ayd_chatbot_deactivate');

function ayd_chatbot_activate() {
    add_option('ayd_chatbot_api_key', '');
    add_option('ayd_chatbot_name', '');
    add_option('ayd_chatbot_code', '');
}

function ayd_chatbot_deactivate() {
    // Cleanup tasks if needed
}
