
jQuery(document).ready(function($) {
    // Admin panel functionality
});
