<?php
/*
Plugin Name: Ask Your Database
Plugin URI: https://askyourdatabase.com
Description: Query your WordPress database with natural language
Version: 2.0.0
Author: Ask Your Database
Author URI: https://askyourdatabase.com
*/

if (!defined('ABSPATH')) exit;

// Add admin menu
add_action('admin_menu', 'ask_your_database_menu');

function ask_your_database_menu() {
    add_menu_page(
        'Ask Your Database', // page title
        'Ask Your Database', // menu title
        'manage_options',    // capability
        'ask-your-database', // menu slug
        'ask_your_database_page', // callback function
        'dashicons-database', // icon
        30 // position
    );
}

function ask_your_database_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    echo '<div class="wrap">';
    echo '<h1>Ask Your Database Settings</h1>';
    echo '<form method="post" action="options.php">';
    settings_fields('ask_your_database_options');
    do_settings_sections('ask_your_database');
    submit_button();
    echo '</form>';
    echo '</div>';
}

// Initialize plugin
function ask_your_database_init() {
    // Register settings
    add_action('admin_init', 'ask_your_database_register_settings');
}
add_action('init', 'ask_your_database_init');

function ask_your_database_register_settings() {
    register_setting('ask_your_database_options', 'ask_your_database_settings');
    
    add_settings_section(
        'ask_your_database_main',
        'Main Settings',
        'ask_your_database_section_text',
        'ask_your_database'
    );
}

function ask_your_database_section_text() {
    echo '<p>Configure your database chatbot settings here.</p>';
}