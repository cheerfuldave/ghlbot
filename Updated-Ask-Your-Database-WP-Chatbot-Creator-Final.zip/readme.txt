=== Ask Your Database WP Chatbot Creator ===
Contributors: Ask Your Database
Tags: chatbot, AI, WP
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Ask Your Database WP Chatbot Creator is a powerful tool to integrate AI-driven chatbots into your WP site. 
Enhance user experience and engage visitors with intelligent, conversational AI.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/ayd-wordpress-chatbot-creator` directory, or install the plugin through the WP plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WP.
3. Navigate to the plugin settings to configure the chatbot.

== Features ==
- Easy-to-use interface for chatbot setup.
- Fully responsive design for mobile and desktop.
- Integration with external APIs for advanced functionality.
- Customizable appearance to match your website’s theme.
- Real-time conversational AI powered by advanced NLP technology.

== Frequently Asked Questions ==
= Does the plugin support multilingual chatbots? =
Yes, the chatbot can be configured to support multiple languages.

= Can I integrate the chatbot with third-party APIs? =
Absolutely! The plugin allows for API integrations with external services.

= Is the chatbot mobile-friendly? =
Yes, it is fully responsive and works seamlessly on mobile devices.

== How to Use ==
1. Navigate to the AYD Chatbot settings page in the WP dashboard.
2. Configure your chatbot settings, such as welcome messages and API keys.
3. Add the chatbot to your site using the provided shortcode: `[ayd_chatbot]`.
4. Save changes and preview the chatbot on your website.

== Shortcodes ==
- `[ayd_chatbot]`: Use this shortcode to add the chatbot to any post or page.

== Support ==
For assistance, please visit our [Support Page](https://yourwebsite.com/support) or email us at support@yourwebsite.com.

== Changelog ==
= 1.0.0 =
* Initial release of the Ask Your Database WP Chatbot Creator plugin.
