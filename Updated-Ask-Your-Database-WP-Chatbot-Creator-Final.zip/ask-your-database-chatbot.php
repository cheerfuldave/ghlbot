<?php
/**
 * Plugin Name: Ask Your Database WP Chatbot
 * Description: A WordPress plugin for integrating chatbots with your database.
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: ask-your-database-wp-chatbot
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Define plugin version
define( 'PLUGIN_NAME_VERSION', '1.0.0' );

// Include the core plugin class
require_once plugin_dir_path( __FILE__ ) . 'includes/class-plugin-name.php';

// Activation and deactivation hooks
function activate_plugin_name() {
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-plugin-name-activator.php';
    Plugin_Name_Activator::activate();
}

function deactivate_plugin_name() {
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-plugin-name-deactivator.php';
    Plugin_Name_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_plugin_name' );
register_deactivation_hook( __FILE__, 'deactivate_plugin_name' );

// Initialize the core plugin class
function run_plugin_name() {
    $plugin = new Plugin_Name();
    $plugin->run();
}
run_plugin_name();
