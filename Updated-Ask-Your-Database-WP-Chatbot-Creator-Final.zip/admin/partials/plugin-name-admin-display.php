<?php
/**
 * Admin area view for the plugin
 */
?>

<div class="wrap">
    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <form method="post" name="ayd_options" action="options.php">
    <?php
        settings_fields('ayd_option_group');
        do_settings_sections('ayd-setting-admin');
        submit_button();
    ?>
    </form>
</div>
