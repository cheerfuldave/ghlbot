// JavaScript for admin functionality
console.log('Admin JS loaded');
