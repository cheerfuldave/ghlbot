<?php
namespace AskYourDatabase\Ajax;

class Preview_Handler {
    public function __construct() {
        add_action('wp_ajax_update_chatbot_preview', array($this, 'update_preview'));
    }
    
    public function update_preview() {
        check_ajax_referer('ayd_preview_nonce', 'nonce');
        
        // Process the preview settings
        $settings = $_POST['settings'];
        parse_str($settings, $parsed_settings);
        
        // Generate preview URL with settings
        $preview_url = add_query_arg(array(
            'preview' => '1',
            'settings' => urlencode(json_encode($parsed_settings))
        ), home_url());
        
        wp_send_json_success(array('preview_url' => $preview_url));
    }
}

new Preview_Handler();
