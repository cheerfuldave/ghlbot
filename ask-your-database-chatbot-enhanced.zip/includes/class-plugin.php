<?php
namespace AskYourDatabase;

class Plugin {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    private function load_dependencies() {
        require_once plugin_dir_path(__FILE__) . 'includes/class-custom-chatbot-integration.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-settings-page.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-preview-handler.php';
    }
    
    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'load_plugin_textdomain'));
    }
    
    public function load_plugin_textdomain() {
        load_plugin_textdomain(
            'ask-your-database',
            false,
            dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );
    }
}

// Initialize the plugin
function init_plugin() {
    return Plugin::get_instance();
}

add_action('plugins_loaded', __NAMESPACE__ . '\init_plugin');
