<?php
namespace AskYourDatabase\Settings;

class Settings_Page {
    private $tabs;
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        
        $this->tabs = array(
            'general' => __('General', 'ask-your-database'),
            'appearance' => __('Appearance', 'ask-your-database'),
            'preview' => __('Preview', 'ask-your-database')
        );
    }
    
    public function enqueue_assets($hook) {
        if (strpos($hook, 'ask-your-database') === false) {
            return;
        }
        
        // Enqueue Roboto font
        wp_enqueue_style(
            'google-roboto',
            'https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap'
        );
        
        // Enqueue jQuery UI
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script('jquery-effects-slide');
        
        // Custom styles
        wp_add_inline_style('admin-bar', "
            .ayd-settings-page {
                font-family: 'Roboto', sans-serif;
                max-width: 1200px;
                margin: 20px auto;
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .ayd-tabs {
                background: #f8f9fa;
                border: none;
                border-radius: 8px 8px 0 0;
            }
            
            .ayd-tabs .ui-tabs-nav {
                background: transparent;
                border: none;
                padding: 20px 20px 0;
            }
            
            .ayd-tabs .ui-tabs-nav li {
                border: none;
                background: transparent;
                margin-right: 10px;
            }
            
            .ayd-tabs .ui-tabs-nav li a {
                color: #666;
                padding: 12px 24px;
                font-weight: 500;
                transition: all 0.3s ease;
            }
            
            .ayd-tabs .ui-tabs-nav li.ui-tabs-active a {
                color: #2271b1;
                border-bottom: 2px solid #2271b1;
            }
            
            .ayd-tab-content {
                padding: 30px;
            }
            
            .ayd-preview-window {
                position: fixed;
                right: -400px;
                top: 32px;
                bottom: 0;
                width: 400px;
                background: #fff;
                box-shadow: -2px 0 4px rgba(0,0,0,0.1);
                transition: right 0.3s ease-in-out;
                z-index: 99999;
            }
            
            .ayd-preview-window.open {
                right: 0;
            }
            
            .ayd-preview-toggle {
                position: absolute;
                left: -40px;
                top: 50%;
                transform: translateY(-50%);
                background: #2271b1;
                color: #fff;
                padding: 10px;
                cursor: pointer;
                border-radius: 4px 0 0 4px;
            }
        ");
        
        // Custom scripts
        wp_add_inline_script('jquery-ui-tabs', "
            jQuery(document).ready(function($) {
                $('.ayd-tabs').tabs();
                
                $('.ayd-preview-toggle').on('click', function() {
                    $('.ayd-preview-window').toggleClass('open');
                });
                
                // AJAX preview update
                $('.ayd-settings-form').on('change', function() {
                    $.ajax({
                        url: ajaxurl,
                        data: {
                            action: 'update_chatbot_preview',
                            settings: $(this).serialize()
                        },
                        success: function(response) {
                            $('.ayd-preview-frame').attr('src', response.preview_url);
                        }
                    });
                });
            });
        ");
    }
    
    public function render_settings_page() {
        ?>
        <div class="wrap ayd-settings-page">
            <h1><?php _e('Ask Your Database Chatbot', 'ask-your-database'); ?></h1>
            
            <div class="ayd-tabs">
                <ul>
                    <?php foreach ($this->tabs as $id => $label): ?>
                        <li><a href="#<?php echo esc_attr($id); ?>"><?php echo esc_html($label); ?></a></li>
                    <?php endforeach; ?>
                </ul>
                
                <div id="general" class="ayd-tab-content">
                    <form class="ayd-settings-form">
                        <?php $this->render_general_settings(); ?>
                    </form>
                </div>
                
                <div id="appearance" class="ayd-tab-content">
                    <form class="ayd-settings-form">
                        <?php $this->render_appearance_settings(); ?>
                    </form>
                </div>
                
                <div id="preview" class="ayd-tab-content">
                    <?php $this->render_preview_section(); ?>
                </div>
            </div>
            
            <div class="ayd-preview-window">
                <div class="ayd-preview-toggle">
                    <span class="dashicons dashicons-visibility"></span>
                </div>
                <iframe class="ayd-preview-frame" src="about:blank" style="width: 100%; height: 100%; border: none;"></iframe>
            </div>
        </div>
        <?php
    }
    
    private function render_general_settings() {
        // Implement your existing settings fields here
    }
    
    private function render_appearance_settings() {
        // Add appearance customization options
    }
    
    private function render_preview_section() {
        // Add preview configuration
    }
}

// Initialize the settings page
new Settings_Page();
