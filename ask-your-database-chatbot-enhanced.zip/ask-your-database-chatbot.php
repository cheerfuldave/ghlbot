<?php
/**
 * Plugin Name: Ask Your Database Chatbot
 * Description: Modern chatbot integration with enhanced UI and features
 * Version: 2.0.0
 * Author: Ask Your Database
 * Author URI: https://askyourdatabase.com
 * Text Domain: ask-your-database
 * Domain Path: /languages
 * License: GPL v2 or later
 */

if (!defined('WPINC')) {
    die;
}

require_once plugin_dir_path(__FILE__) . 'includes/class-plugin.php';
