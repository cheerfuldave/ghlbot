import './styles/admin.scss';

/**
 * A void function.
 *
 * @param {jQuery} $ The jQuery object to be used in the function body
 */
( ( $ ) => {
	'use strict';
	$( () => {} );
	// Place your administration-specific JavaScript here
} )( jQuery );
