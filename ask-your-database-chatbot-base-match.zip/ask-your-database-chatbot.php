<?php
/**
 * Plugin Name: WordPress Ask Your Database Custom Chatbot
 * Description: Easily integrate customizable chatbots into your WordPress site using the Ask Your Database API
 * Version: 2.3
 * Author: Ask Your Database
 * Author URI: https://askyourdatabase.com
 * Text Domain: ask-your-database-chatbot
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Activation/Deactivation hooks
register_activation_hook(__FILE__, 'ayd_chatbot_activate');
register_deactivation_hook(__FILE__, 'ayd_chatbot_deactivate');

function ayd_chatbot_activate() {
    // Set default options on activation
    add_option('ayd_chatbot_api_key', '');
    for($i = 1; $i <= 5; $i++) {
        add_option('ayd_chatbot_name_' . $i, '');
        add_option('ayd_chatbot_id_' . $i, '');
    }
    add_option('ayd_chatbot_selected_users', array());
}

function ayd_chatbot_deactivate() {
    // Cleanup if needed
}

// Add menu item
add_action('admin_menu', 'ayd_chatbot_add_admin_menu');
function ayd_chatbot_add_admin_menu() {
    add_menu_page(
        'Chatbot Settings',
        'Chatbot',
        'manage_options',
        'ayd-chatbot-settings',
        'ayd_chatbot_settings_page',
        'dashicons-admin-generic',
        90
    );
}

// Add settings page
function ayd_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h1>Chatbot Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ayd_chatbot_options');
            do_settings_sections('ayd_chatbot_settings');
            submit_button('Save Changes', 'primary', 'submit', true);
            ?>
        </form>
        <h2>Get Chat Code/API</h2>
        <iframe src="https://www.askyourdatabase.com/dashboard/chatbot" style="width: 100%; height: 600px; border: none;"></iframe>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'ayd_chatbot_settings_init');
function ayd_chatbot_settings_init() {
    register_setting('ayd_chatbot_options', 'ayd_chatbot_api_key');
    for($i = 1; $i <= 5; $i++) {
        register_setting('ayd_chatbot_options', 'ayd_chatbot_name_' . $i);
        register_setting('ayd_chatbot_options', 'ayd_chatbot_id_' . $i);
    }
    register_setting('ayd_chatbot_options', 'ayd_chatbot_selected_users');

    add_settings_section(
        'ayd_chatbot_general_section',
        'General Settings',
        'ayd_chatbot_general_section_callback',
        'ayd_chatbot_settings'
    );

    add_settings_field(
        'ayd_chatbot_api_key',
        'API Key',
        'ayd_chatbot_api_key_render',
        'ayd_chatbot_settings',
        'ayd_chatbot_general_section'
    );

    // Add chatbot configuration fields
    for($i = 1; $i <= 5; $i++) {
        add_settings_field(
            'ayd_chatbot_config_' . $i,
            'Chatbot ' . $i,
            'ayd_chatbot_config_render',
            'ayd_chatbot_settings',
            'ayd_chatbot_general_section',
            array('number' => $i)
        );
    }

    add_settings_field(
        'ayd_chatbot_selected_users',
        'Selected Users',
        'ayd_chatbot_selected_users_render',
        'ayd_chatbot_settings',
        'ayd_chatbot_general_section'
    );
}

function ayd_chatbot_general_section_callback() {
    echo 'Configure your chatbot settings below:';
}

function ayd_chatbot_api_key_render() {
    $api_key = get_option('ayd_chatbot_api_key');
    ?>
    <input type='text' name='ayd_chatbot_api_key' value='<?php echo esc_attr($api_key); ?>' style='width: 300px;'>
    <?php
}

function ayd_chatbot_config_render($args) {
    $i = $args['number'];
    $name = get_option('ayd_chatbot_name_' . $i);
    $id = get_option('ayd_chatbot_id_' . $i);
    ?>
    <div style="margin-bottom: 10px;">
        <input type='text' name='ayd_chatbot_name_<?php echo $i; ?>' value='<?php echo esc_attr($name); ?>' placeholder='Chatbot Name' style='width: 200px; margin-right: 10px;'>
        <input type='text' name='ayd_chatbot_id_<?php echo $i; ?>' value='<?php echo esc_attr($id); ?>' placeholder='Chatbot ID' style='width: 200px;'>
    </div>
    <?php
}

function ayd_chatbot_selected_users_render() {
    $selected_users = get_option('ayd_chatbot_selected_users', array());
    $users = get_users();
    ?>
    <select name='ayd_chatbot_selected_users[]' multiple style='width: 300px; height: 150px;'>
        <?php foreach($users as $user) : ?>
            <option value='<?php echo esc_attr($user->ID); ?>' <?php echo in_array($user->ID, $selected_users) ? 'selected' : ''; ?>>
                <?php echo esc_html($user->display_name); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <p class="description">Hold Ctrl/Cmd to select multiple users</p>
    <?php
}

// Shortcode functionality
function ayd_chatbot_shortcode($atts) {
    $atts = shortcode_atts(array(
        'chatbot' => ''
    ), $atts);

    // Find the chatbot ID based on the name
    $chatbot_id = '';
    for($i = 1; $i <= 5; $i++) {
        if(get_option('ayd_chatbot_name_' . $i) === $atts['chatbot']) {
            $chatbot_id = get_option('ayd_chatbot_id_' . $i);
            break;
        }
    }

    if(empty($chatbot_id)) {
        return '';
    }

    return '<div class="chatbot-container">
        <iframe src="https://chat.askyourdatabase.com/' . esc_attr($chatbot_id) . '" style="width: 100%; height: 600px; border: none;"></iframe>
    </div>';
}
add_shortcode('chatbot', 'ayd_chatbot_shortcode');

// Add settings link on plugin page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ayd_chatbot_settings_link');
function ayd_chatbot_settings_link($links) {
    $settings_link = '<a href="admin.php?page=ayd-chatbot-settings">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// Add CSS
add_action('wp_head', 'ayd_chatbot_add_css');
function ayd_chatbot_add_css() {
    ?>
    <style>
        .chatbot-container {
            max-width: 800px;
            margin: 20px auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
        }
    </style>
    <?php
}
