<?php
/**
 * Plugin Name: WordPress Ask Your Database Custom Chatbot
 * Description: Easily integrate customizable chatbots into your WordPress site using the Ask Your Database API
 * Version: 2.3
 * Author: Ask Your Database
 * Author URI: https://askyourdatabase.com
 * Text Domain: ask-your-database-chatbot
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Activation/Deactivation hooks
register_activation_hook(__FILE__, 'ayd_chatbot_activate');
register_deactivation_hook(__FILE__, 'ayd_chatbot_deactivate');

function ayd_chatbot_activate() {
    // Set default options on activation
    add_option('ayd_chatbot_api_key', '');
    add_option('ayd_chatbot_position', 'bottom-right');
    add_option('ayd_chatbot_theme', 'light');
}

function ayd_chatbot_deactivate() {
    // Cleanup if needed
}

// Add menu item
add_action('admin_menu', 'ayd_chatbot_add_admin_menu');
function ayd_chatbot_add_admin_menu() {
    add_menu_page(
        'Chatbot Settings',
        'Chatbot',
        'manage_options',
        'ayd-chatbot-settings',
        'ayd_chatbot_settings_page',
        'dashicons-admin-generic',
        90
    );
}

// Add settings page
function ayd_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h1>Chatbot Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ayd_chatbot_options');
            do_settings_sections('ayd_chatbot_settings');
            submit_button('Save Changes', 'primary', 'submit', true, ['style' => 'background-color: #0073aa; color: white;']);
            ?>
        </form>
        <h2>Get Chat Code/API</h2>
        <iframe src="https://www.askyourdatabase.com/dashboard/chatbot" style="width: 100%; height: 600px; border: none;"></iframe>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'ayd_chatbot_settings_init');
function ayd_chatbot_settings_init() {
    register_setting('ayd_chatbot_options', 'ayd_chatbot_api_key');
    register_setting('ayd_chatbot_options', 'ayd_chatbot_position');
    register_setting('ayd_chatbot_options', 'ayd_chatbot_theme');

    add_settings_section(
        'ayd_chatbot_general_section',
        'General Settings',
        'ayd_chatbot_general_section_callback',
        'ayd_chatbot_settings'
    );

    add_settings_field(
        'ayd_chatbot_api_key',
        'API Key',
        'ayd_chatbot_api_key_render',
        'ayd_chatbot_settings',
        'ayd_chatbot_general_section'
    );

    add_settings_field(
        'ayd_chatbot_position',
        'Position',
        'ayd_chatbot_position_render',
        'ayd_chatbot_settings',
        'ayd_chatbot_general_section'
    );

    add_settings_field(
        'ayd_chatbot_theme',
        'Theme',
        'ayd_chatbot_theme_render',
        'ayd_chatbot_settings',
        'ayd_chatbot_general_section'
    );
}

function ayd_chatbot_general_section_callback() {
    echo 'Configure your chatbot settings below:';
}

function ayd_chatbot_api_key_render() {
    $api_key = get_option('ayd_chatbot_api_key');
    ?>
    <input type='text' name='ayd_chatbot_api_key' value='<?php echo esc_attr($api_key); ?>'>
    <?php
}

function ayd_chatbot_position_render() {
    $position = get_option('ayd_chatbot_position', 'bottom-right');
    ?>
    <select name='ayd_chatbot_position'>
        <option value='bottom-right' <?php selected($position, 'bottom-right'); ?>>Bottom Right</option>
        <option value='bottom-left' <?php selected($position, 'bottom-left'); ?>>Bottom Left</option>
    </select>
    <?php
}

function ayd_chatbot_theme_render() {
    $theme = get_option('ayd_chatbot_theme', 'light');
    ?>
    <select name='ayd_chatbot_theme'>
        <option value='light' <?php selected($theme, 'light'); ?>>Light</option>
        <option value='dark' <?php selected($theme, 'dark'); ?>>Dark</option>
    </select>
    <?php
}

// Original shortcode and functionality
function ayd_chatbot_shortcode($atts) {
    $api_key = get_option('ayd_chatbot_api_key');
    $position = get_option('ayd_chatbot_position', 'bottom-right');
    $theme = get_option('ayd_chatbot_theme', 'light');
    
    return '<div class="ayd-chatbot" data-position="' . esc_attr($position) . '" data-theme="' . esc_attr($theme) . '">
        <iframe src="https://chat.askyourdatabase.com/' . esc_attr($api_key) . '" style="width: 100%; height: 600px; border: none;"></iframe>
    </div>';
}
add_shortcode('ayd_chatbot', 'ayd_chatbot_shortcode');

// Add settings link on plugin page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ayd_chatbot_settings_link');
function ayd_chatbot_settings_link($links) {
    $settings_link = '<a href="admin.php?page=ayd-chatbot-settings">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}
